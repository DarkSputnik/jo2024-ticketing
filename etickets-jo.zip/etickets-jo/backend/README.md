# API e-tickets JO (local)

1) Copier `.env.example` vers `.env` et adapter si besoin.  
2) `npm install`  
3) `npm run seed` (crée BDD + offres + admin)  
4) `npm run dev` → http://localhost:4000

Admin par défaut :  
- email: admin@jo.fr  
- mdp: Admin!2024