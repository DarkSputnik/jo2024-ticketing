import 'dotenv/config';
import bcrypt from 'bcrypt';
import db from './db.js';

// Détails des offres disponible par défuat
const offers = [
  { title: 'Billet Solo',    type: 'solo',    price_cents: 5000 },
  { title: 'Billet Duo',     type: 'duo',     price_cents: 9000 },
  { title: 'Billet Famille', type: 'famille', price_cents: 16000 }
];

for (const o of offers) {
  db.prepare('INSERT INTO offers (title,type,price_cents) VALUES (?,?,?)').run(o.title, o.type, o.price_cents);
}

// Admin par défaut
const email = process.env.ADMIN_EMAIL || 'admin@jo.fr';
const pass  = process.env.ADMIN_PASSWORD || 'Admin!2024';
const hash  = await bcrypt.hash(pass, 10);
db.prepare('INSERT OR IGNORE INTO users (name,email,password_hash,account_key,role) VALUES (?,?,?,?,?)')
  .run('Administrateur', email, hash, 'ADM-'+Date.now(), 'ADMIN');

console.log('Seed done.');
