PRAGMA foreign_keys = ON;

-- ==============================
-- Table UTILISATEUR
-- ==============================
CREATE TABLE IF NOT EXISTS utilisateur (
    idUtilisateur INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT NOT NULL,
    prenom TEXT,
    email TEXT UNIQUE NOT NULL,
    motDePasseHash TEXT NOT NULL,
    role TEXT CHECK(role IN ('USER','ADMIN')) DEFAULT 'USER',
    dateCreation TEXT DEFAULT CURRENT_TIMESTAMP,
    estVerifie BOOLEAN DEFAULT 0,
    facteur2FA BOOLEAN DEFAULT 0
);

-- ==============================
-- Table OFFRE
-- ==============================
CREATE TABLE IF NOT EXISTS offre (
    idOffre INTEGER PRIMARY KEY AUTOINCREMENT,
    libelle TEXT NOT NULL,
    type TEXT NOT NULL,                       -- solo, duo ou famille / ...
    description TEXT,
    nbPlacesIncluses INTEGER DEFAULT 1,
    prixTTC DECIMAL(10,2) NOT NULL,
    actif BOOLEAN DEFAULT 1
);

-- ==============================
-- Table PANIER
-- ==============================
CREATE TABLE IF NOT EXISTS panier (
    idPanier INTEGER PRIMARY KEY AUTOINCREMENT,
    idUtilisateur INTEGER NOT NULL,
    dateCreation TEXT DEFAULT CURRENT_TIMESTAMP,
    etat TEXT CHECK(etat IN ('OUVERT','VALIDE','ABANDONNE')) DEFAULT 'OUVERT',
    FOREIGN KEY (idUtilisateur) REFERENCES utilisateur(idUtilisateur)
);

-- ==============================
-- Table LIGNEPANIER
-- ==============================
CREATE TABLE IF NOT EXISTS lignePanier (
    idLigne INTEGER PRIMARY KEY AUTOINCREMENT,
    idPanier INTEGER NOT NULL,
    idOffre INTEGER NOT NULL,
    quantite INTEGER NOT NULL DEFAULT 1,
    prixUnitaireSnapshot DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (idPanier) REFERENCES panier(idPanier),
    FOREIGN KEY (idOffre) REFERENCES offre(idOffre)
);

-- ==============================
-- Table COMMANDE
-- ==============================
CREATE TABLE IF NOT EXISTS commande (
    idCommande INTEGER PRIMARY KEY AUTOINCREMENT,
    idUtilisateur INTEGER NOT NULL,
    dateCommande TEXT DEFAULT CURRENT_TIMESTAMP,
    totalTTC DECIMAL(10,2) NOT NULL,
    etat TEXT CHECK(etat IN ('PAYEE','ANNULEE','REMBOURSEE')) DEFAULT 'PAYEE',
    idPaiementMock TEXT,
    refCommande TEXT,
    FOREIGN KEY (idUtilisateur) REFERENCES utilisateur(idUtilisateur)
);

-- ==============================
-- Table CLECOMPTE (clé 1)
-- ==============================
CREATE TABLE IF NOT EXISTS cleCompte (
    idCleCpt INTEGER PRIMARY KEY AUTOINCREMENT,
    idUtilisateur INTEGER NOT NULL,
    valeurCle TEXT NOT NULL,                -- UUID
    dateGeneration TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (idUtilisateur) REFERENCES utilisateur(idUtilisateur)
);

-- ==============================
-- Table CLEACHAT (clé 2)
-- ==============================
CREATE TABLE IF NOT EXISTS cleAchat (
    idCleAchat INTEGER PRIMARY KEY AUTOINCREMENT,
    idCommande INTEGER NOT NULL,
    valeurCle TEXT NOT NULL,                -- UUID
    dateGeneration TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (idCommande) REFERENCES commande(idCommande)
);

-- ==============================
-- Table TICKET
-- ==============================
CREATE TABLE IF NOT EXISTS ticket (
    idTicket INTEGER PRIMARY KEY AUTOINCREMENT,
    idCommande INTEGER NOT NULL,
    idUtilisateur INTEGER NOT NULL,
    idOffre INTEGER NOT NULL,
    qrcodeValeur TEXT NOT NULL,             -- HMAC ou hash concatène clé1+clé2
    statut TEXT CHECK(statut IN ('VALIDE','UTILISE','REVOQUE')) DEFAULT 'VALIDE',
    dateGeneration TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (idCommande) REFERENCES commande(idCommande),
    FOREIGN KEY (idUtilisateur) REFERENCES utilisateur(idUtilisateur),
    FOREIGN KEY (idOffre) REFERENCES offre(idOffre)
);

-- ==============================
-- Table SCANACCES
-- ==============================
CREATE TABLE IF NOT EXISTS scanAcces (
    idScan INTEGER PRIMARY KEY AUTOINCREMENT,
    idTicket INTEGER NOT NULL,
    dateScan TEXT DEFAULT CURRENT_TIMESTAMP,
    resultat TEXT CHECK(resultat IN ('OK','REFUS')),
    motifRefus TEXT,
    FOREIGN KEY (idTicket) REFERENCES ticket(idTicket)
);
