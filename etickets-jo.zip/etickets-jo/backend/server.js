import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { v4 as uuid } from 'uuid';
import QRCode from 'qrcode';
import db from './db.js';
import { z } from 'zod';

const app = express();
app.use(cors({ origin: 'http://localhost:5173', credentials: true }));
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || 'devsecret';

function authMiddleware(role) {
  return (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Unauthorized' });
    try {
      const payload = jwt.verify(token, JWT_SECRET);
      if (role && payload.role !== role) return res.status(403).json({ error: 'Forbidden' });
      req.user = payload;
      next();
    } catch {
      res.status(401).json({ error: 'Invalid token' });
    }
  };
}

/* -------- AUTH -------- */
const RegisterSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8)
    .regex(/[A-Z]/, 'need uppercase')
    .regex(/[a-z]/, 'need lowercase')
    .regex(/[0-9]/, 'need digit')
    .regex(/[^A-Za-z0-9]/, 'need special char')
});

app.post('/api/auth/register', async (req, res) => {
  const parse = RegisterSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: 'Validation error', details: parse.error.issues });

  const { name, email, password } = parse.data;
  const exists = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  if (exists) return res.status(409).json({ error: 'Email already used' });

  const password_hash = await bcrypt.hash(password, 10);
  const account_key = uuid(); // clé 1
  const stmt = db.prepare('INSERT INTO users (name,email,password_hash,account_key) VALUES (?,?,?,?)');
  const info = stmt.run(name, email, password_hash, account_key);

  const user = { id: info.lastInsertRowid, name, email, role: 'USER' };
  const token = jwt.sign(user, JWT_SECRET, { expiresIn: '2h' });
  res.json({ user, token });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const payload = { id: user.id, name: user.name, email: user.email, role: user.role };
  const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '2h' });
  res.json({ user: payload, token });
});

/* -------- prix (public + admin CRUD) -------- */
app.get('/api/offers', (req, res) => {
  const offers = db.prepare('SELECT * FROM offers ORDER BY id DESC').all();
  res.json(offers);
});

app.post('/api/offers', authMiddleware('ADMIN'), (req, res) => {
  const { title, type, price_cents } = req.body;
  if (!title || !type || !Number.isInteger(price_cents)) return res.status(400).json({ error: 'Invalid body' });
  const info = db.prepare('INSERT INTO offers (title,type,price_cents) VALUES (?,?,?)')
    .run(title, type, price_cents);
  res.json({ id: info.lastInsertRowid, title, type, price_cents });
});

app.put('/api/offers/:id', authMiddleware('ADMIN'), (req, res) => {
  const { title, type, price_cents } = req.body;
  const { id } = req.params;
  db.prepare('UPDATE offers SET title=?, type=?, price_cents=? WHERE id=?')
    .run(title, type, price_cents, id);
  res.json({ ok: true });
});

app.delete('/api/offers/:id', authMiddleware('ADMIN'), (req, res) => {
  db.prepare('DELETE FROM offers WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

/* -------- paiement + commandes + TICKETS -------- */
app.post('/api/checkout', authMiddleware(), async (req, res) => {
  // body: items [{offer_id, qty}]
  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  if (!items.length) return res.status(400).json({ error: 'Empty cart' });

  // calc total & vérification des offres
  let total = 0;
  const valid = [];
  for (const it of items) {
    const offer = db.prepare('SELECT * FROM offers WHERE id=?').get(it.offer_id);
    if (!offer || !Number.isInteger(it.qty) || it.qty < 1) return res.status(400).json({ error: 'Invalid items' });
    total += offer.price_cents * it.qty;
    valid.push({ offer, qty: it.qty });
  }

  // MOCK paiement OK
  const purchase_key = uuid(); // clé 2

  const trx = db.transaction(() => {
    const info = db.prepare('INSERT INTO orders (user_id,total_cents,purchase_key) VALUES (?,?,?)')
      .run(req.user.id, total, purchase_key);
    const order_id = info.lastInsertRowid;

    for (const { offer, qty } of valid) {
      db.prepare('INSERT INTO order_items (order_id,offer_id,qty) VALUES (?,?,?)')
        .run(order_id, offer.id, qty);
      // Générer un ticket par place (solo=1, duo=2, famille=4 -> géré par qty saisi côté front)
      for (let i = 0; i < qty; i++) {
        const account_key = db.prepare('SELECT account_key FROM users WHERE id=?').get(req.user.id).account_key;
        const finalRaw = account_key + ':' + purchase_key;
        const final_key = awaitHash(finalRaw); // SHA-256
        const qr_png_base64 = QRCode.toDataURL(final_key); // généré plus bas via helper sync
        db.prepare('INSERT INTO tickets (order_id,user_id,offer_id,final_key,qr_png_base64) VALUES (?,?,?,?,?)')
          .run(order_id, req.user.id, offer.id, final_key, qr_png_base64);
      }
    }
    return order_id;
  });

  const order_id = await trx();
  res.json({ ok: true, order_id });
});

// helper « sync » pour QR (QRCode.toDataURL est Promise)
function QRSync(data) {
  return QRCode.toDataURL(data);
}
function sha256(str) {
  // petit SHA-256 portable (sans dépendance crypto web)
  return (await import('crypto')).createHash('sha256').update(str).digest('hex');
}
async function awaitHash(s){ return sha256(s); }

/* -------- MES TICKETS -------- */
app.get('/api/my-tickets', authMiddleware(), (req, res) => {
  const rows = db.prepare(`
    SELECT t.id, t.final_key, t.qr_png_base64, o.title AS offer_title
    FROM tickets t
    JOIN offers o ON o.id = t.offer_id
    WHERE t.user_id=?
    ORDER BY t.id DESC
  `).all(req.user.id);
  res.json(rows);
});

/* -------- STATS ADMIN -------- */
app.get('/api/admin/sales', authMiddleware('ADMIN'), (req, res) => {
  const rows = db.prepare(`
    SELECT o.id, o.title, SUM(oi.qty) AS units, COALESCE(SUM(oi.qty * o.price_cents),0) AS revenue
    FROM offers o
    LEFT JOIN order_items oi ON oi.offer_id = o.id
    GROUP BY o.id
    ORDER BY o.id
  `).all();
  res.json(rows);
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log('API running on http://localhost:'+port));
