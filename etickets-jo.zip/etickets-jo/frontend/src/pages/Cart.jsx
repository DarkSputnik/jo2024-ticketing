import { useState } from "react";
import { api } from "../api";
import { getToken } from "../auth";

export default function Cart(){
  const [items, setItems] = useState(JSON.parse(localStorage.getItem('cart')||'[]'));
  const total = items.reduce((s,i)=>s+i.price_cents*i.qty,0);

  const update = (idx, delta)=>{
    const copy = [...items];
    copy[idx].qty = Math.max(1, copy[idx].qty + delta);
    setItems(copy);
    localStorage.setItem('cart', JSON.stringify(copy));
  };

  const checkout = async ()=>{
    try{
      const token = getToken();
      if(!token) return alert('Connecte-toi avant de payer.');
      const payload = { items: items.map(i=>({ offer_id:i.offer_id, qty:i.qty })) };
      const r = await api('/checkout', { method:'POST', body: payload, token });
      localStorage.removeItem('cart');
      alert('Paiement mock OK. Commande #'+r.order_id);
    }catch(e){ alert(e.message); }
  };

  return (
    <div className="container">
      <h2>Panier</h2>
      {!items.length ? <p>Votre panier est vide.</p> :
      <>
        {items.map((it,idx)=>(
          <div key={idx} className="card" style={{display:'flex',gap:10,alignItems:'center'}}>
            <div style={{flex:1}}>
              <b>{it.title}</b><br/>
              {(it.price_cents/100).toFixed(2)} €
            </div>
            <div>
              <button className="btn secondary" onClick={()=>update(idx,-1)}>-</button>
              <span style={{margin:'0 .5rem'}}>{it.qty}</span>
              <button className="btn secondary" onClick={()=>update(idx,1)}>+</button>
            </div>
          </div>
        ))}
        <h3>Total : {(total/100).toFixed(2)} €</h3>
        <button className="btn" onClick={checkout}>Payer (mock)</button>
      </>}
    </div>
  );
}
