import { useState } from "react";
import { api } from "../api";
import { setToken, setUser } from "../auth";
import { useNavigate } from "react-router-dom";

export default function Register(){
  const [name,setName]=useState('');
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const nav = useNavigate();
  const submit = async e=>{
    e.preventDefault();
    try{
      const r = await api('/auth/register',{method:'POST', body:{name,email,password}});
      setToken(r.token); setUser(r.user); nav('/');
    }catch(err){ alert(err.message); }
  };
  return (
    <div className="container">
      <h2>Inscription</h2>
      <form onSubmit={submit} className="card">
        <input className="input" placeholder="Nom Prénom" value={name} onChange={e=>setName(e.target.value)} />
        <input className="input" style={{marginTop:8}} placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="input" style={{marginTop:8}} type="password" placeholder="Mot de passe (8+, Aa1!)" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="btn" style={{marginTop:8}}>Créer le compte</button>
      </form>
    </div>
  );
}
