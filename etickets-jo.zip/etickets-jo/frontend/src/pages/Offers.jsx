import { useEffect, useState } from "react";
import { api } from "../api";
import OfferCard from "../components/OfferCard";

export default function Offers(){
  const [offers, setOffers] = useState([]);
  useEffect(()=>{ api('/offers').then(setOffers).catch(console.error); },[]);
  const onAdd = (offer)=>{
    const cart = JSON.parse(localStorage.getItem('cart')||'[]');
    cart.push({ offer_id: offer.id, title: offer.title, price_cents: offer.price_cents, qty: 1 });
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Ajouté au panier');
  };
  return (
    <div className="container">
      <h2>Offres disponibles</h2>
      <div className="grid">
        {offers.map(o=> <OfferCard key={o.id} offer={o} onAdd={onAdd}/>)}
      </div>
    </div>
  );
}
