import { useEffect, useState } from "react";
import { api } from "../api";
import { getToken } from "../auth";
import ProtectedRoute from "../components/ProtectedRoute";

function Inner(){
  const [offers,setOffers]=useState([]);
  const [form,setForm]=useState({title:'',type:'solo',price_cents:0});
  const token = getToken();

  const load = ()=> api('/offers').then(setOffers);
  useEffect(()=>{ load(); },[]);

  const add = async ()=>{
    await api('/offers',{method:'POST', body:form, token});
    setForm({title:'',type:'solo',price_cents:0}); load();
  };
  const update = async (o)=>{
    await api('/offers/'+o.id,{method:'PUT', body:o, token}); load();
  };
  const del = async (id)=>{
    await api('/offers/'+id,{method:'DELETE', token}); load();
  };

  const [stats,setStats]=useState([]);
  const loadStats = ()=> api('/admin/sales',{token}).then(setStats);
  useEffect(()=>{ loadStats(); },[]);

  return (
    <div className="container">
      <h2>Administration</h2>

      <div className="card">
        <h3>Créer / Modifier une offre</h3>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr auto',gap:8}}>
          <input className="input" placeholder="Titre" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/>
          <input className="input" placeholder="Type" value={form.type} onChange={e=>setForm({...form,type:e.target.value})}/>
          <input className="input" type="number" placeholder="Prix (cents)" value={form.price_cents} onChange={e=>setForm({...form,price_cents:parseInt(e.target.value||0)})}/>
          <button className="btn" onClick={add}>Ajouter</button>
        </div>
      </div>

      <h3>Offres</h3>
      {offers.map(o=>(
        <div key={o.id} className="card" style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr auto auto',gap:8}}>
          <input className="input" value={o.title} onChange={e=>o.title=e.target.value}/>
          <input className="input" value={o.type} onChange={e=>o.type=e.target.value}/>
          <input className="input" type="number" value={o.price_cents} onChange={e=>o.price_cents=parseInt(e.target.value||0)}/>
          <button className="btn secondary" onClick={()=>update(o)}>Enregistrer</button>
          <button className="btn" onClick={()=>del(o.id)}>Supprimer</button>
        </div>
      ))}

      <h3>Ventes par offre</h3>
      <div className="grid">
        {stats.map(s=>(
          <div key={s.id} className="card">
            <b>{s.title}</b>
            <div>Places vendues : {s.units ?? 0}</div>
            <div>CA : {((s.revenue ?? 0)/100).toFixed(2)} €</div>
          </div>
        ))}
      </div>
    </div>
  );
}
export default function Admin(){ return <ProtectedRoute><Inner/></ProtectedRoute>; }
