import { useState } from "react";
import { api } from "../api";
import { setToken, setUser } from "../auth";
import { useNavigate } from "react-router-dom";

export default function Login(){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const nav = useNavigate();
  const submit = async e=>{
    e.preventDefault();
    try{
      const r = await api('/auth/login',{method:'POST', body:{email,password}});
      setToken(r.token); setUser(r.user); nav('/');
    }catch(err){ alert(err.message); }
  };
  return (
    <div className="container">
      <h2>Connexion</h2>
      <form onSubmit={submit} className="card">
        <input className="input" placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="input" type="password" placeholder="mot de passe" value={password} onChange={e=>setPassword(e.target.value)} style={{marginTop:8}}/>
        <button className="btn" style={{marginTop:8}}>Se connecter</button>
      </form>
    </div>
  );
}
