export default function Home(){
  return (
    <div className="container">
      <h1>Jeux Olympiques France 2024</h1>
      <p>Bienvenue sur la plateforme officielle d’e-tickets. Consultez les offres et réservez vos billets en toute sécurité.</p>
    </div>
  );
}
