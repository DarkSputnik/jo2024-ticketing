import { useEffect, useState } from "react";
import { api } from "../api";
import { getToken } from "../auth";
import ProtectedRoute from "../components/ProtectedRoute";
import QRModal from "../components/QRModal";

function Inner(){
  const [list,setList]=useState([]); const [open,setOpen]=useState(false); const [png,setPng]=useState(null);
  useEffect(()=>{ api('/my-tickets',{token:getToken()}).then(setList).catch(console.error); },[]);
  return (
    <div className="container">
      <h2>Mes billets</h2>
      {!list.length ? <p>Vous n’avez pas encore de billet.</p> :
        list.map(t=>(
          <div key={t.id} className="card" style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <div>
              <b>{t.offer_title}</b><br/><small>Clé: {t.final_key.slice(0,16)}…</small>
            </div>
            <button className="btn secondary" onClick={()=>{setPng(t.qr_png_base64); setOpen(true);}}>Voir QR</button>
          </div>
        ))
      }
      <QRModal open={open} onClose={()=>setOpen(false)} png={png}/>
    </div>
  );
}
export default function MyTickets(){ return <ProtectedRoute><Inner/></ProtectedRoute>; }
