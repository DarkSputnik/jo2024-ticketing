export function getToken(){ return localStorage.getItem('token'); }
export function setToken(t){ localStorage.setItem('token', t); }
export function clearToken(){ localStorage.removeItem('token'); }
export function getUser(){ const s=localStorage.getItem('user'); return s?JSON.parse(s):null; }
export function setUser(u){ localStorage.setItem('user', JSON.stringify(u)); }
export function isAdmin(){ return getUser()?.role === 'ADMIN'; }
