export default function QRModal({open, onClose, png}){
  if(!open) return null;
  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.6)'}}>
      <div style={{background:'#fff',maxWidth:420,margin:'10vh auto',padding:20,borderRadius:12}}>
        <h3>QR Code</h3>
        <img src={png} alt="qr" style={{width:'100%'}}/>
        <div style={{display:'flex',justifyContent:'flex-end',marginTop:10}}>
          <button className="btn secondary" onClick={onClose}>Fermer</button>
        </div>
      </div>
    </div>
  );
}
