export default function OfferCard({offer, onAdd}){
  return (
    <div className="card">
      <h3>{offer.title}</h3>
      <p>Type : <b>{offer.type}</b></p>
      <p>Prix : {(offer.price_cents/100).toFixed(2)} €</p>
      <button className="btn" onClick={()=>onAdd(offer)}>Ajouter au panier</button>
    </div>
  );
}
