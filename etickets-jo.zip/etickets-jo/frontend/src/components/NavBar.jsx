import { Link, useNavigate } from "react-router-dom";
import { getUser, clearToken, setUser, isAdmin } from "../auth";

export default function Navbar(){
  const nav = useNavigate();
  const user = getUser();
  const logout = ()=>{
    clearToken(); setUser(null); nav('/login');
  };
  return (
    <div className="nav">
      <div style={{fontWeight:'700'}}>E-Tickets JO</div>
      <Link to="/">Accueil</Link>
      <Link to="/offers">Offres</Link>
      <Link to="/cart">Panier</Link>
      {user && <Link to="/my-tickets">Mes billets</Link>}
      {isAdmin() && <Link to="/admin">Admin</Link>}
      <div style={{marginLeft:'auto'}} />
      {!user ? (<>
        <Link to="/login">Connexion</Link>
        <Link to="/register">Inscription</Link>
      </>) : (
        <>
          <span className="badge">{user.name}</span>
          <button className="btn secondary" onClick={logout}>Déconnexion</button>
        </>
      )}
    </div>
  );
}
